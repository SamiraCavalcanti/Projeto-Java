
package projetojogo;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author SDDA_
 */
public class ProjetoJogo {


    public static void main(String[] args) {
      Scanner entrada = new Scanner(System.in);
        while(true){
       
       String[] pedrapapeltesoura ={"pedra","papel","tesoura"};
       String movimentoPC = pedrapapeltesoura[new Random().nextInt(pedrapapeltesoura.length)];//comprimento do array
       
       String movimentoJogador;
       while(true){ //validação
       System.out.println("Por favor escolha seu movimento(pedra,papel ou tesoura)");
        movimentoJogador = entrada.nextLine();
       if (movimentoJogador.equals("pedra")||movimentoJogador.equals("papel")||movimentoJogador.equals("tesoura")){
           break;
           
       }
       System.out.println(movimentoJogador + "\nEsse moviemnto não é válido.");
    }
       System.out.println("Computador escolheu: " + movimentoPC);
       if(movimentoJogador.equals(movimentoPC)){
         System.out.println("Jogo empatado!");
 }
       else if(movimentoJogador.equals("pedra")){
           if(movimentoPC.equals("papel")){
               System.out.println("Você perdeu!");
       }else  if(movimentoPC.equals("tesoura")){
               System.out.println("Você ganhou!");
}
}
       
       else if(movimentoJogador.equals("papel")){
           if(movimentoPC.equals("pedra")){
               System.out.println("Você ganhou!");
       }else  if(movimentoPC.equals("tesoura")){
               System.out.println("Você perdeu!");
    }
       }
        else if(movimentoJogador.equals("tesoura")){
           if(movimentoPC.equals("papel")){
               System.out.println("Você ganhou!");
       }else  if(movimentoPC.equals("pedra")){
               System.out.println("Você perdeu!");
       }
        }
    System.out.println("Deseja jogar novamente?(s/n)");
    String jogarNovamente = entrada.nextLine();
    if(!jogarNovamente.equals("s")){
        break;
    }
    
   }
    }
}